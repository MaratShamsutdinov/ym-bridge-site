# Yandex Music → Last.fm Bridge

Scrobble your Yandex Music listening to Last.fm — automatically, in real time.

## Download

- 💻 **[Desktop app (Windows)](https://ym-bridge.mytunnel.us.com/downloads/ym-bridge-companion-windows-x64-v0.1.1.zip)** — download the optional Windows x64 companion
- 🧩 **[Chrome extension](https://chromewebstore.google.com/detail/cjemkikpabifhldcdkopinpejahljcin?utm_source=item-share-cb)** — install directly from the Chrome Web Store

> Companion downloads are published on the official YM Bridge domain.
> Extension updates are delivered through the Chrome Web Store.
